# AEI – Kit de diffusion sur Facebook, Instagram et X

Remplacez `[LIEN]` par l'adresse du site (idéalement la fiche du bien, ex. `https://www.VOTRE-DOMAINE.fr/#/bien/villa-jarry`).

## Où publier, dans cet ordre

1. **Page Facebook professionnelle « AEI »** (pas votre profil personnel). Épinglez le lien du site et votre numéro WhatsApp. Photo de profil : le logo. Photo de couverture : `partage-reseaux.jpg`.
2. **Groupes Facebook locaux** : « Immobilier Guadeloupe », groupes par commune ou de la diaspora. Lisez leurs règles, certains interdisent les annonces commerciales.
3. **Instagram** : un compte lié à la page Facebook. Publiez photos et reels, lien dans la bio.
4. **X** : utile pour la visibilité, moins pour la vente immobilière. Un message court avec photo suffit.
5. **WhatsApp** : statut et liste de diffusion. Le canal le plus efficace localement. Les fiches ont un bouton « Partager sur WhatsApp ».

## Textes prêts à publier

### Villa à Baie-Mahault (455 000 €)
**Facebook / Instagram**
> 🌴 VILLA CRÉOLE AVEC PISCINE – BAIE-MAHAULT (Jarry)
> 145 m² sur 824 m² de terrain arboré · 3 chambres + mezzanine · piscine · deux terrasses couvertes · dépendance
> 💶 455 000 €
> 📞 06 71 06 25 28 · WhatsApp
> Fiche complète et photos : [LIEN]
> #Guadeloupe #ImmobilierGuadeloupe #BaieMahault #VillaAVendre #Piscine

**X** (moins de 280 caractères)
> 🌴 Villa créole avec piscine à Baie-Mahault : 145 m², terrain de 824 m², 3 chambres + mezzanine. 455 000 €. Photos et contact : [LIEN] #Guadeloupe #Immobilier

### Appartement à Pointe-à-Pitre (310 000 €)
**Facebook / Instagram**
> ⚓ APPARTEMENT À RAFRAÎCHIR – POINTE-À-PITRE, À DEUX PAS DE LA MARINA
> 75 m² · 2 chambres · salle d'eau accessible PMR · jardin et terrasse avec vue sur la marina
> 💶 310 000 €
> Un bien à rénover, pour créer un intérieur à votre goût.
> Fiche et photos : [LIEN] · 📞 06 71 06 25 28
> #PointeAPitre #Guadeloupe #Marina #ImmobilierGuadeloupe

**X**
> ⚓ Appartement de 75 m² à Pointe-à-Pitre, à deux pas de la marina, jardin et terrasse. À rafraîchir. 310 000 €. [LIEN] #Guadeloupe #Immobilier

### Maison à La Désirade (250 000 €)
**Facebook / Instagram**
> 🏝️ MAISON À RÉNOVER – LA DÉSIRADE
> 135 m² · construite en 1990 · 2 chambres + mezzanine · grand balcon couvert · terrasse en toiture
> 💶 250 000 €
> Travaux à prévoir : un beau projet pour qui aime les défis.
> Photos et informations : [LIEN] · 📞 06 71 06 25 28
> #LaDésirade #Guadeloupe #MaisonAVendre #Rénovation

**X**
> 🏝️ Maison de 135 m² à La Désirade (1990), 2 chambres + mezzanine, balcon couvert, terrasse. Travaux à prévoir. 250 000 €. [LIEN] #LaDésirade #Guadeloupe

## Règles à respecter

- **Le prix et la commune** doivent figurer dans l'annonce.
- **Le DPE** (classe énergétique) doit en principe apparaître dans une annonce immobilière en France. Pour la villa (en cours) et La Désirade (non communiqué), le faire réaliser avant de diffuser largement.
- **Statut** : écrire « apporteur d'affaires », jamais « agence immobilière ». Ne pas parler de « mandat » ni de « frais d'agence ».
- **Photos** : ne publier que celles dont le propriétaire a autorisé l'usage, sans visages ni plaques d'immatriculation.
- **Facebook Ads** : Meta place les annonces immobilières dans une catégorie spéciale, avec un ciblage restreint (âge, code postal). Vérifier les règles actuelles avant de payer une publicité.
- **Ne jamais publier l'adresse exacte** : « communiquée sur demande ».
- **Réponses aux messages** : renvoyer vers WhatsApp ou le téléphone plutôt que de discuter de prix dans les commentaires publics.

## Sécurité de vos comptes

- Authentification à deux facteurs sur Facebook, Instagram, X et sur l'e-mail associé.
- Compte créé avec l'adresse pro `f.casi@live.fr`, pas avec un e-mail partagé.
- Ne jamais donner son mot de passe à un prestataire : l'ajouter comme « administrateur » de la page à la place.
- Méfiez-vous des faux messages « votre page va être supprimée » : ils servent à voler des comptes.
