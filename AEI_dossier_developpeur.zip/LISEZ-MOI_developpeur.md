# AEI – Antilles Expertises Immobilières : mise en ligne du site

Document à remettre au développeur, avec le dossier `site/`.

## 1. Le projet en deux phrases

Site vitrine d'un apporteur d'affaires immobilier en Guadeloupe : annonces de biens à vendre, fiches détaillées, service payant d'« avis de valeur », contact par WhatsApp, téléphone et e-mail. Le site est déjà réalisé ; la mission consiste à le **mettre en ligne proprement et de façon sécurisée**.

## 2. Ce qui est livré

| Fichier | Rôle |
|---|---|
| `site/index.html` | Le site complet (HTML, CSS, JavaScript et images intégrés, environ 3,7 Mo). Aucune dépendance à installer. |
| `site/_headers` | En-têtes de sécurité (Netlify et Cloudflare Pages). Testés : le site fonctionne avec. |
| `site/robots.txt` | Autorise l'indexation. Ajouter l'adresse du plan du site. |

Seule ressource externe : la police Google Fonts (Bricolage Grotesque et Figtree). Le site reste lisible sans elle. Pour un site 100 % sans tiers, les héberger localement.

## 3. Statut juridique de l'éditeur (à respecter dans les textes)

- AEI exerce comme **apporteur d'affaires**, sans carte professionnelle : le site ne doit jamais se présenter comme une agence immobilière ni parler de « mandat » ou de « transaction conclue par AEI ».
- Les « avis de valeur » sont des analyses de marché. Ils ne sont **pas** des expertises certifiées. Le texte d'avertissement de la section est à conserver.
- À faire valider par l'éditeur (ou son conseil) avant ouverture publique : mentions légales complètes, SIRET, forme juridique, hébergeur, et éventuelle obligation d'immatriculation liée à l'activité d'apporteur d'affaires.

## 4. Hébergement recommandé

Le site est statique : pas de serveur, pas de base de données, donc très peu de surface d'attaque.

| Option | Coût | Adapté si |
|---|---|---|
| **Netlify** ou **Cloudflare Pages** | Gratuit | Le plus simple : glisser le dossier `site/`. HTTPS automatique, `_headers` pris en compte. |
| GitHub Pages | Gratuit | Dépôt public ou privé. Les en-têtes de sécurité ne sont pas configurables. |
| Hébergeur français (OVH, o2switch) | Environ 3 à 10 € / mois | Préférence pour un hébergement en France. Reporter les en-têtes du fichier `_headers` dans le `.htaccess`. |

Étapes :
1. Créer le compte au **nom de l'éditeur** (pas au nom du développeur), avec authentification à deux facteurs.
2. Déposer le dossier `site/`.
3. Acheter le **nom de domaine** au nom de l'éditeur (environ 10 € par an pour un .fr), le pointer vers l'hébergement.
4. Forcer le HTTPS et la redirection `www` vers le domaine principal.
5. Vérifier l'affichage sur mobile (majorité des visiteurs) et sur les principaux navigateurs.

## 5. Sécuriser l'accès

Il y a trois besoins différents. Le client doit choisir :

**A. Site public, mais durci (recommandé)**
- HTTPS obligatoire et en-têtes de sécurité du fichier `_headers`.
- Comptes d'hébergement et de domaine protégés par authentification à deux facteurs.
- Aucun formulaire ni base de données : les demandes partent par WhatsApp ou e-mail, le site ne stocke aucune donnée personnelle. Cela limite fortement les obligations RGPD.

**B. Version de préversion privée, avant l'ouverture**
- Protection par mot de passe : Netlify (option « Password protection »), ou Cloudflare Access, ou fichier `.htpasswd` sur un hébergeur classique.
- Ajouter `<meta name="robots" content="noindex">` tant que le site n'est pas public.

**C. Protéger les informations sensibles des biens**
- Les fiches n'affichent pas l'adresse exacte : elles indiquent seulement la commune, le quartier ou « localisation communiquée sur demande ». À conserver.
- Les photos portent le logo AEI. Ne pas y intégrer de plaque d'immatriculation, de numéro de rue ni de visage.
- Si un accès réservé aux acquéreurs qualifiés est souhaité (documents, dossiers), il faut un espace connecté : c'est un développement supplémentaire, hors du périmètre actuel.

Ce que la sécurité ne peut pas garantir : une fois publiée, une page publique peut être copiée. La protection réelle est de ne pas publier ce qui est sensible.

## 6. Points à renseigner avant la mise en ligne

- **E-mail et téléphone** : `CONFIG` au début du script de `index.html` (WhatsApp 33671062528, e-mail f.casi@live.fr). Le pied de page et les boutons les reprennent.
- **Numéro de téléphone** : les présentations mentionnent aussi le 06 90 98 48 48. Faire confirmer le numéro à afficher.
- **Pied de page** : SIRET et mentions légales, à compléter.
- **Tarifs** de la section « Avis de valeur » : ce sont des exemples (`PLANS`).
- **Fiche de La Désirade** : DPE non communiqué, localisation précise à confirmer.
- **Villa de Baie-Mahault** : DPE « en cours » ; commune (Baie-Mahault ou Saint-Claude ?) à confirmer.
- **Politique de confidentialité** et gestion des cookies : à ajouter seulement si un outil de mesure d'audience est installé.

## 7. Structure du code (pour la maintenance)

Un seul fichier. Tout ce qui se modifie se trouve dans le dernier bloc `<script>` :

- `CONFIG` : téléphone, WhatsApp, e-mail.
- `LISTINGS` : les biens. Pour en ajouter un, copier un objet existant (titre, prix, commune, surface, sections de description) et ajouter ses photos dans l'objet `IMG`.
- `ZONES` : les 32 communes de Guadeloupe, réparties en trois zones.
- `PLANS` : les formules d'avis de valeur.

Navigation par `#/bien/<id>` (pas de rechargement). Pour un meilleur référencement (une vraie URL par bien), prévoir dans une deuxième phase une génération de pages statiques.

## 8. Améliorations possibles (phase 2, sur devis)

- Extraire les photos du HTML vers des fichiers `.webp` (chargement plus rapide, page d'accueil plus légère).
- Une page statique par bien, plan du site (`sitemap.xml`) et données structurées pour Google.
- Fiche Google Business Profile et diffusion des annonces sur Leboncoin, SeLoger et Bien'ici.
- Mesure d'audience respectueuse de la vie privée (Plausible, Matomo).
- Traduction en anglais pour la clientèle étrangère.
- Paiement en ligne des avis de valeur (Stripe), si le client le souhaite.

## 9. Recette (à cocher avant de livrer)

- [ ] Le site s'affiche en HTTPS, sans avertissement du navigateur.
- [ ] Les 3 biens s'ouvrent, les photos se chargent, les boutons « Appeler », WhatsApp et e-mail fonctionnent.
- [ ] Affichage correct sur iPhone, Android et ordinateur.
- [ ] Les 32 communes apparaissent dans les menus.
- [ ] Les mentions légales sont complètes.
- [ ] L'éditeur possède les accès (hébergement, domaine, DNS).

## 10. Partage sur Facebook, X et WhatsApp

- `site/index.html` contient déjà les balises **Open Graph** et **Twitter Card** : un lien collé sur Facebook, X ou WhatsApp affiche une vignette avec titre et image.
- Remplacer `https://www.VOTRE-DOMAINE.fr/` par l'adresse réelle dans le `<head>` (`canonical`, `og:url`, `og:image`, `twitter:image`). L'image `site/partage-reseaux.jpg` (1200 × 630) doit être déposée à la racine du site.
- Limite connue : les fiches de biens utilisent une adresse en `#/bien/...`, que Facebook et X ne lisent pas. Un lien vers une fiche affichera donc la vignette générale du site. Pour une vignette propre à chaque bien (photo et prix), il faut une page statique par bien (phase 2, section 8).
- Après la mise en ligne, vérifier la vignette avec le **Débogueur de partage Facebook** (Sharing Debugger).
- Les textes de publication prêts à l'emploi sont dans `KIT_RESEAUX_SOCIAUX.md`.
